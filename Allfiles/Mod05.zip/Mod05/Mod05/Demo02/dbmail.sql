-- Module 5 Demo 2 File 1

-- Step 1 - enable Database Mail
USE master 
GO 
sp_configure 'show advanced options',1 
GO 
RECONFIGURE WITH OVERRIDE 
GO 
sp_configure 'Database Mail XPs', 1 
GO 
RECONFIGURE  
GO 

-- Step 2 - Create an email account
EXECUTE msdb.dbo.sysmail_add_account_sp 
@account_name = 'SQLAlerts', 
@description = 'Account for Automated DBA Notifications', 
@email_address = 'sqlagenttest@localhost.local', 
@replyto_address = 'sqlagenttest@localhost.local', 
@display_name = 'SQL Agent', 
@mailserver_name = 'localhost', 
@port = 8000
GO

-- Step 3 - create a default profile
EXECUTE msdb.dbo.sysmail_add_profile_sp 
@profile_name = 'dbmail_default', 
@description = 'Profile for sending Automated DBA Notifications' 
GO

-- Step 4 - grant permission to the profile
EXECUTE msdb.dbo.sysmail_add_principalprofile_sp 
@profile_name = 'dbmail_default', 
@principal_name = 'public', 
@is_default = 1 ;
GO

-- Step 5 - connect the account to the profile
EXECUTE msdb.dbo.sysmail_add_profileaccount_sp   
@profile_name = 'dbmail_default',   
@account_name = 'SQLAlerts',   
@sequence_number = 1;  
GO

-- Step 6 - send test email
-- Step 6a - set up test SMTP server on Linux host
/* Python3 script:
import smtpd, asyncore
server = smtpd.DebuggingServer(('localhost', 8000), None)
asyncore.loop()
*/
--To exit (on Linux):
--1) Background the task - press: CTRL+Z 
--2) type: kill %1  
--3) press: ENTER


-- Step 6b - send test email
EXECUTE msdb.dbo.sp_send_dbmail 
@profile_name = 'dbmail_default', 
@recipients = 'recipient-test@localhost.local', 
@Subject = 'Testing DBMail', 
@Body = 'This message is a test for DBMail' 
GO

-- Step 7 - configure default profile
/*
sudo /opt/mssql/bin/mssql-conf set sqlagent.databasemailprofile dbmail_default
sudo systemctl restart mssql-server.service
*/

-- Step 8 - create operator
EXEC msdb.dbo.sp_add_operator 
@name=N'test_operator', 
@enabled=1, 
@email_address=N'test_operator@localhost.local'

-- Step 9 - create a job
USE [msdb]
GO

IF EXISTS (SELECT * FROM msdb.dbo.sysjobs WHERE name = N'Test Agent Job')
    EXEC msdb.dbo.sp_delete_job @job_name=N'Test Agent Job', @delete_unused_schedule=1
GO

BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Test Agent Job', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'testt', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select 1', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO

-- Step 10 - add a notification
EXEC msdb.dbo.sp_update_job 
@job_name='Test Agent Job', 
@notify_level_email=1, 
@notify_email_operator_name=N'test_operator' 
GO

-- Step 11 - start the job
EXEC msdb.dbo.sp_start_job @job_name=N'Test Agent Job'





