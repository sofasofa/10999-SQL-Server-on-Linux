--Module 7 Lab 2 File 2

-- Step S1 - enable AlwaysOn_health Xevent session
USE master;
GO
ALTER EVENT SESSION  AlwaysOn_health ON SERVER WITH (STARTUP_STATE=ON);
GO

-- Step S2 - create a db mirroring user
CREATE LOGIN dbm_login WITH PASSWORD = 'Pa55w.rd';
CREATE USER dbm_user FOR LOGIN dbm_login;
GO

--Step S3 - restore the certificate
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa55w.rdMasterKey';
CREATE CERTIFICATE dbm_certificate   
    AUTHORIZATION dbm_user
    FROM FILE = '/var/opt/mssql/data/dbm_certificate.cer'
    WITH PRIVATE KEY (
    FILE = '/var/opt/mssql/data/dbm_certificate.pvk',
    DECRYPTION BY PASSWORD = 'Pa55w.rdCertKey'
            );

--Step S4 create an endpoint
CREATE ENDPOINT [Hadr_endpoint]
    AS TCP (LISTENER_IP = (0.0.0.0), LISTENER_PORT = 5022)
    FOR DATA_MIRRORING (
        ROLE = ALL,
        AUTHENTICATION = CERTIFICATE dbm_certificate,
        ENCRYPTION = REQUIRED ALGORITHM AES
        );
ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [dbm_login];

--Step S5 join AG
ALTER AVAILABILITY GROUP [rag1] JOIN WITH (CLUSTER_TYPE = NONE);
ALTER AVAILABILITY GROUP [rag1] GRANT CREATE ANY DATABASE;


-- Step S6 monitoring
SELECT name FROM sys.databases;

SELECT DB_NAME(database_id) AS 'database', synchronization_state_desc, * FROM sys.dm_hadr_database_replica_states;

SELECT * FROM SalesAG.dbo.RefData;
