--Module 7 Lab 2 File 1

--Step P1 - setup
USE master;
GO

CREATE DATABASE SalesAG;
GO
ALTER DATABASE SalesAG SET RECOVERY FULL;
GO

CREATE TABLE SalesAG.dbo.RefData (id int, val1 char(1));
GO

INSERT SalesAG.dbo.RefData(id,val1)
VALUES (2,'A'),(3,'B'),(4,'C');
GO


--Step P2 - enable AlwaysOn_health Xevent session



--Step P3 - create a db mirroring user
CREATE LOGIN dbm_login WITH PASSWORD = 'Pa55w.rd';
CREATE USER dbm_user FOR LOGIN dbm_login;
GO

--Step P4 create a certificate
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa55w.rdMasterKey';
CREATE CERTIFICATE dbm_certificate WITH SUBJECT = 'dbm';
BACKUP CERTIFICATE dbm_certificate
   TO FILE = '/var/opt/mssql/data/dbm_certificate.cer'
   WITH PRIVATE KEY (
           FILE = '/var/opt/mssql/data/dbm_certificate.pvk',
           ENCRYPTION BY PASSWORD = 'Pa55w.rdCertKey'
       );

--Step P5 create an endpoint
CREATE ENDPOINT [Hadr_endpoint]
    AS TCP (LISTENER_IP = (0.0.0.0), LISTENER_PORT = <port>)
    FOR DATA_MIRRORING (
        ROLE = ALL,
        AUTHENTICATION = CERTIFICATE <cert>,
        ENCRYPTION = REQUIRED ALGORITHM AES
        );
ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [dbm_login];

--Step P6 create availability group
CREATE AVAILABILITY GROUP [rag1]
   WITH (CLUSTER_TYPE = <cluster type>)
   FOR REPLICA ON
   N'<primary, varchar(15),>' WITH (
      ENDPOINT_URL = N'tcp://<primary, varchar(15),>:5022',
      AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT,
      FAILOVER_MODE = MANUAL,
      SEEDING_MODE = AUTOMATIC ,
      PRIMARY_ROLE (ALLOW_CONNECTIONS = READ_WRITE),  
      SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL)
   ),
   N'<secondary, varchar(15),>' WITH ( 
      ENDPOINT_URL = N'tcp://<secondary, varchar(15),>:5022', 
      AVAILABILITY_MODE = ASYNCHRONOUS_COMMIT,
      FAILOVER_MODE = MANUAL,
      SEEDING_MODE = AUTOMATIC,
      PRIMARY_ROLE (ALLOW_CONNECTIONS = READ_WRITE),
      SECONDARY_ROLE (ALLOW_CONNECTIONS = ALL)
   );

 ALTER AVAILABILITY GROUP [rag1] GRANT CREATE ANY DATABASE;
   
--Step P7 add DB to AG
BACKUP DATABASE SalesAG 
   TO DISK = N'/var/opt/mssql/data/SalesAG.bak';
GO
ALTER AVAILABILITY GROUP <group name> ADD DATABASE SalesAG;
GO

