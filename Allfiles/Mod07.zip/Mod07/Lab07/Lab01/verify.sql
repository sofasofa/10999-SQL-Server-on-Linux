--Module 7 Lab 1 File 3

--Step 1 - run on primary to make a data change
USE MarketingLS;
GO

--create a table
CREATE TABLE RefData (id int, val1 int);
GO
INSERT RefData (id, val1) VALUES (1,1),(2,2),(3,3);
GO

-- Wait at least 60 seconds before running step 2

-- Step 2 - run on secondary to review data change

USE master;
GO
RESTORE DATABASE MarketingLS WITH RECOVERY;
GO
USE MarketingLS;
GO
SELECT * FROM RefData;
GO
