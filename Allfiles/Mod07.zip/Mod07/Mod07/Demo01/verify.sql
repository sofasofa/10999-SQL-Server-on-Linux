--Module 7 Demo 1 File 3

--Step 1 - run on primary to make a data change and trigger a transaction log backup
USE Log_Ship_DB;
GO

--create a table
CREATE TABLE test1 (id int, val1 int);
GO
INSERT test1 (id, val1) VALUES (1,1),(2,2),(3,3);
GO

EXEC msdb.dbo.sp_start_job N'LSBackup_Log_Ship_DB' ;  
GO 

--Step 2 - run on secondary to restore backup, then review data change
USE msdb ;  
GO  
EXEC dbo.sp_start_job N'LSCopy_Log_Ship_DB' ;  
GO  
EXEC dbo.sp_start_job N'LSRestore_Log_Ship_DB' ;  
GO 
 
WAITFOR DELAY '00:00:30'
RESTORE DATABASE Log_Ship_DB WITH RECOVERY;
GO

USE Log_Ship_DB;
GO
SELECT * FROM test1;
GO

