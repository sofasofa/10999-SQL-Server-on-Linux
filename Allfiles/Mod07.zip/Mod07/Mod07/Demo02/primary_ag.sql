--Module 7 Demo 2 File 1

--Step P1 - setup
USE master;
GO

CREATE DATABASE ag_demo;
GO
ALTER DATABASE ag_demo SET RECOVERY FULL;
GO

--Step P2 - enable AlwaysOn_health Xevent session
ALTER EVENT SESSION  AlwaysOn_health ON SERVER WITH (STARTUP_STATE=ON);
GO

--Step P3 - create a db mirroring user
CREATE LOGIN dbm_login WITH PASSWORD = 'Pa55w.rd';
CREATE USER dbm_user FOR LOGIN dbm_login;
GO

--Step P4 create a certificate
CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Pa55w.rdMasterKey';
CREATE CERTIFICATE dbm_certificate WITH SUBJECT = 'dbm';
BACKUP CERTIFICATE dbm_certificate
   TO FILE = '/var/opt/mssql/data/dbm_certificate.cer'
   WITH PRIVATE KEY (
           FILE = '/var/opt/mssql/data/dbm_certificate.pvk',
           ENCRYPTION BY PASSWORD = 'Pa55w.rdCertKey'
       );

--Step P5 create an endpoint
CREATE ENDPOINT [Hadr_endpoint]
    AS TCP (LISTENER_IP = (0.0.0.0), LISTENER_PORT = 5022)
    FOR DATA_MIRRORING (
        ROLE = ALL,
        AUTHENTICATION = CERTIFICATE dbm_certificate,
        ENCRYPTION = REQUIRED ALGORITHM AES
        );
ALTER ENDPOINT [Hadr_endpoint] STATE = STARTED;
GRANT CONNECT ON ENDPOINT::[Hadr_endpoint] TO [dbm_login];

--Step P6 create availability group
CREATE AVAILABILITY GROUP [ag1]
   WITH (CLUSTER_TYPE = EXTERNAL)
   FOR REPLICA ON
   N'<primary, varchar(15),>' WITH (
      ENDPOINT_URL = N'tcp://<primary, varchar(15),>:5022',
      AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
      FAILOVER_MODE = EXTERNAL,
      SEEDING_MODE = AUTOMATIC
   ),
   N'<secondary, varchar(15),>' WITH ( 
      ENDPOINT_URL = N'tcp://<secondary, varchar(15),>:5022', 
      AVAILABILITY_MODE = SYNCHRONOUS_COMMIT,
      FAILOVER_MODE = EXTERNAL,
      SEEDING_MODE = AUTOMATIC
   );

ALTER AVAILABILITY GROUP [ag1] GRANT CREATE ANY DATABASE;

CREATE LOGIN pacemaker WITH PASSWORD=N'Pa55w.rd';
GO
GRANT VIEW SERVER STATE TO pacemaker
GRANT ALTER, CONTROL, VIEW DEFINITION ON AVAILABILITY GROUP::ag1 TO pacemaker
GO

--Step P7 add DB to AG
BACKUP DATABASE ag_demo 
   TO DISK = N'/var/opt/mssql/data/ag_demo.bak';
GO
ALTER AVAILABILITY GROUP [ag1] ADD DATABASE ag_demo;
GO

