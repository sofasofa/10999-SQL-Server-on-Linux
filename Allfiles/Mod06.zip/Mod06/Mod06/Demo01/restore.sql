-- Module 6 Demo 1 File 1

USE [master]
GO

-- Step 1 view backup header
RESTORE HEADERONLY FROM  DISK = N'/tmp/sales_br.bak' ;

-- Step 2 view backup files
RESTORE FILELISTONLY FROM  DISK = N'/tmp/sales_br.bak' ;

-- Step 3 restore
RESTORE DATABASE [Sales_BR] FROM  DISK = N'/tmp/sales_br.bak' WITH  FILE = 1,  
MOVE N'AdventureworksLT_Data' TO N'/var/opt/mssql/data/Sales_BR.mdf',  
MOVE N'AdventureworksLT_Log' TO N'/var/opt/mssql/data/Sales_BR.ldf',  
NOUNLOAD,  
STATS = 5

GO

-- Step 4 check database catalog
SELECT name FROM sys.Databases

