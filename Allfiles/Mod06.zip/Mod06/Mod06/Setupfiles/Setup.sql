USE master
GO

-- Drop and restore Databases
IF EXISTS(SELECT * FROM sys.sysdatabases WHERE name = 'Sales_BR')
BEGIN
	DROP DATABASE Sales_BR
END
GO



RESTORE DATABASE [Sales_BR] FROM  DISK = N'$(SUBDIR)SetupFiles\Sales_BR.bak' WITH  REPLACE,
MOVE N'AdventureworksLT_Data' TO N'$(SUBDIR)SetupFiles\Sales_BR.mdf', 
MOVE N'AdventureworksLT_Log' TO N'$(SUBDIR)SetupFiles\Sales_BR_log.ldf'
GO
ALTER AUTHORIZATION ON DATABASE::Sales_BR TO [ADVENTUREWORKS\Student];
GO

IF EXISTS(SELECT * FROM sys.sysdatabases WHERE name = 'Sales_IE')
BEGIN
	DROP DATABASE Sales_IE
END
GO

RESTORE DATABASE [Sales_IE] FROM  DISK = N'$(SUBDIR)SetupFiles\Sales_BR.bak' WITH  REPLACE,
MOVE N'AdventureworksLT_Data' TO N'$(SUBDIR)SetupFiles\Sales_IE.mdf', 
MOVE N'AdventureworksLT_Log' TO N'$(SUBDIR)SetupFiles\Sales_IE_log.ldf'
GO
ALTER AUTHORIZATION ON DATABASE::Sales_IE TO [ADVENTUREWORKS\Student];
GO



