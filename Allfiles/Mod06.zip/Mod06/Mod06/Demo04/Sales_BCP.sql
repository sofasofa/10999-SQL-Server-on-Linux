USE master
GO

DROP DATABASE IF EXISTS Sales_BCP;
GO

CREATE DATABASE Sales_BCP;
GO

USE Sales_BCP
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

DROP TABLE IF EXISTS dbo.Customer;
GO

CREATE TABLE dbo.Customer(
	CustomerID int NOT NULL,
	Title nvarchar(8) NULL,
	FirstName nvarchar(50) NOT NULL,
	MiddleName nvarchar(50) NULL,
	LastName nvarchar(50) NOT NULL,
	CompanyName nvarchar(128) NULL,
	Phone nvarchar(25) NULL
) ;
GO

INSERT dbo.Customer (CustomerID, Title, FirstName, MiddleName, LastName,CompanyName,Phone)
VALUES(1,'Mr.','Orlando','N.','Gee','A Bike Store','245-555-0173'),
(2,'Mr.','Keith','','Harris','Progressive Sports','170-555-0127'),
(3,'Ms.','Donna','F.','Carreras','Advanced Bike Components','279-555-0130'),
(4,'Ms.','Janet','M.','Gates','Modular Cycle Systems','710-555-0173'),
(5,'Mr.','Lucy','','Harrington','Metropolitan Sports Supply','828-555-0186'),
(6,'Ms.','Rosmarie','J.','Carroll','Aerobic Exercise Company','244-555-0112'),
(7,'Mr.','Dominic','P.','Gash','Associated Bikes','192-555-0173'),
(10,'Ms.','Kathleen','M.','Garza','Rural Cycle Emporium','150-555-0127'),
(11,'Ms.','Katherine','','Harding','Sharp Bikes','926-555-0159'),
(12,'Mr.','Johnny','A.','Caprio','Bikes and Motorbikes','112-555-0191'),
(16,'Mr.','Christopher','R.','Beck','Bulk Discount Store','1 (11) 500 555-0132'),
(18,'Mr.','David','J.','Liu','Catalog Store','440-555-0132'),
(19,'Mr.','John','A.','Beaver','Center Cycle Shop','521-555-0195'),
(20,'Ms.','Jean','P.','Handley','Central Discount Store','582-555-0113'),
(21,'','Jinghao','','Liu','Chic Department Stores','928-555-0116'),
(22,'Ms.','Linda','E.','Burnett','Travel Systems','121-555-0121'),
(23,'Mr.','Kerim','','Hanif','Bike World','216-555-0122'),
(24,'Mr.','Kevin','','Liu','Eastside Department Store','926-555-0164'),
(25,'Mr.','Donald','L.','Blanton','Coalition Bike Company','357-555-0161'),
(28,'Ms.','Jackie','E.','Blackwell','Commuter Bicycle Store','972-555-0163');

DROP TABLE IF EXISTS dbo.ExchangeRate;
GO


CREATE TABLE dbo.ExchangeRate
(from_currency_code char(3) NOT NULL,
 to_currency_code char(3) NOT NULL,
 rate_date date NOT NULL,
 rate decimal (18,4)
)
GO

