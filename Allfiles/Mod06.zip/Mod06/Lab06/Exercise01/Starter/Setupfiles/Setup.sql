USE master
GO

-- Drop and restore Databases
IF EXISTS(SELECT * FROM sys.sysdatabases WHERE name = 'FirstPayroll')
BEGIN
	DROP DATABASE FirstPayroll
END
GO



RESTORE DATABASE [FirstPayroll] FROM  DISK = N'$(SUBDIR)SetupFiles\FirstPayroll.bak' WITH  REPLACE,
MOVE N'AdventureworksLT_Data' TO N'$(SUBDIR)SetupFiles\FirstPayroll.mdf', 
MOVE N'AdventureworksLT_Log' TO N'$(SUBDIR)SetupFiles\FirstPayroll_log.ldf'
GO
ALTER AUTHORIZATION ON DATABASE::FirstPayroll TO [ADVENTUREWORKS\Student];
GO



